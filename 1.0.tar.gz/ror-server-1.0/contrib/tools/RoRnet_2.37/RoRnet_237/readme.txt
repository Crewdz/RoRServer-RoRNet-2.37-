This is the Rigs of Rods multiplayer Python connection library for the Rigs of
Rods multiplayer protocol version RoRnet_2.37 (RoR 0.38).

An example of how to use this is included in client.py.
To test it, replace the user and server settings at the bottom of the file.
Then run with Python 2.7.3.
