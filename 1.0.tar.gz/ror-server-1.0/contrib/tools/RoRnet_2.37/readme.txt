This is a Rigs of Rods multiplayer chat client.
Commands you can use:
/disconnect
/quit
/list
/kick
/ban
/unban
/bans
/say
/whisper
To use this, replace the user and server settings at the top of the file.
Then run with Python 2.7.3.