#define _HAVE_SSL /* build SSL class? */
