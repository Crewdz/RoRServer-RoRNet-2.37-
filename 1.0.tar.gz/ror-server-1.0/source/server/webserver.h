#pragma once
#ifndef WEBSERVER_H__
#define WEBSERVER_H__

int startWebserver(int port);
int stopWebserver();

#endif //WEBSERVER_H__
